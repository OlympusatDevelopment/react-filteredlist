/**
 * Views are a collection of filter group objects
 */
import seller from './seller';
import buyer from './buyer';

export default [
    buyer,
    seller
];