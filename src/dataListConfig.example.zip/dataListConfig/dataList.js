/**
 * This is the main configuration for the list portion of the DataList component.
 * It has configuration for "show checkboxes" etc...
 */
export default args=>{
    return{};
}