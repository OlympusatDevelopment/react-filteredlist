import xhr from 'xhr';
import Promise from 'bluebird';
import _ from 'underscore';

import config from '../config';

export default {
    getDefaults : (type)=>new Promise((resolve,reject)=>{
        let defaults = localStorage.getItem('dl.defaults');

        // Check storage to see if we've already made this request
        if(defaults){
            try{defaults = JSON.parse(defaults)}catch(e){}
            resolve({options: _.sortBy(defaults[type],'entityValue')});
        }else{
            let opts = {
                method: 'POST',
                uri:config.defaultsApiUrl,
                headers: {
                    'Content-Type': 'application/json'
                }
            };

            xhr(opts,(err,res,body)=>{
                if(err){ console.log(err) }
                const defaults = JSON.parse(body);

                localStorage.setItem('dl.defaults',JSON.stringify(defaults));

                resolve({options:_.sortBy(defaults[type],'entityValue')});
            });
        }

    }),

    request : (opts)=>new Promise((resolve,reject)=>{
        xhr(opts,(err,res,body)=>{
            if(err){ console.log(err) }

            resolve(JSON.parse(body));
        });
    })
}