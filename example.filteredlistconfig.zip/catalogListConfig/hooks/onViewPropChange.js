import {
  storage_getItem,
  storage_setItem,
  prefs_merge,
  prefs_createInitial
} from '../../../../appUtils/fun';

/**
 * Hook used to know when the view props change
 */
/** 
* See the onInit hook. We write to localStorage here to save user preferences, 
* but we read those preferences onInit
*/
export default ({ prop, checked, viewId, selectedView }) => {
  const lsPropsPrefkey = "oh.prefs.props";
  const lsPrefs = storage_getItem(lsPropsPrefkey);
  const mutatedPrefs = lsPrefs
    ? prefs_merge(lsPrefs)(prop, checked, viewId)
    : prefs_createInitial(selectedView)(prop, checked);

    storage_setItem(lsPropsPrefkey, mutatedPrefs);
}

