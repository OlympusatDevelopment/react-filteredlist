/**
 * Hook used to know when the app is initialized...
 */
import {
  storage_getItem,
} from '../../../../appUtils/fun';
import _utils from '../_utils';

export default (app, datalistConfig) => {
  _utils.getDefaults('genres');// Request defaults to ensure they're set on app load

  // ANy data passed here gets included in the preferences branch of the store..
  return setPreferences => {
    /**
    * Must call back when the return funtion closure has been defined or the app won't load.
    */
    setPreferences(storage_getItem("oh.prefs.props"));
  }
}