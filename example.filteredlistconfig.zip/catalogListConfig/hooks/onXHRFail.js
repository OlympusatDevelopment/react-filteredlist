/**
 * Hook gets called when the xhr request kicks back an error
 * @param args
 * @returns {*}
 */
export default (err,body)=>{
    return body;
}