import Promise from 'bluebird';
import _utils from '../_utils';
import _ from 'underscore';

import config from '../config';

/**
 * Hook gets called when the xhr request returns successfully
 * @param body
 * @returns {*}
 */
export default (body,resolve,reject)=>{
    console.log('ON XHR SUCCESS', body);
    resolve(body);
};
