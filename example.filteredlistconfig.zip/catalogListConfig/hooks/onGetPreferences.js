/**
 * Hook used to fetch saved preferences
 */
import {
  storage_getItem,
} from '../../../../appUtils/fun';

/**
 * Must be syncronous code
 */
export default () => storage_getItem("oh.prefs.props")