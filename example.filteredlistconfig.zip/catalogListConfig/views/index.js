/**
 * Views are a collection of filter group objects
 */
import catalog from './catalog';
import versions from './versions';

export default [
    catalog,
    versions,
];