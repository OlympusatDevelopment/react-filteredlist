export default ()=>{
    return localStorage.getItem('dl.defaults');
};