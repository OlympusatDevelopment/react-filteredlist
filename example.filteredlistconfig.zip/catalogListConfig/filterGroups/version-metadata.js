import genres from '../filters/genres';
import language from '../filters/language';
import state from '../filters/state';
import hasStills from '../filters/still';
import tags from '../filters/tags';
import showType from '../filters/showType';
import showTitles from '../filters/showTitles';
import hasVideos from '../filters/video';
import hasArtwork from '../filters/artwork';

/**
 * Filter groups are objects that have group configuration properties and a collection of filters
 */
export default {
    label : 'Metadata',
    defaultOpen: false,
    accordian:{
        color:{
            background: '#105caa',
            text:'#fff'
        }
    },
    filters:[
        state,
        genres,
        language,
        showType,
        showTitles,
        tags,
        hasStills,
        hasVideos,
        hasArtwork
    ]
};