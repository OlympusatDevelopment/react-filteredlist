import sortState from "../filters/sort-state";
import sortTitleCode from "../filters/sort-titleCode";
import sortType from "../filters/sort-type";
import sortDateEdited from "../filters/sort-dateEdited";
import sortCreatedDate from "../filters/sort-createdDate";
import sortHouseId from "../filters/sort-houseId";
import sortPrimaryNetwork from "../filters/sort-primaryNetwork";

/**
 * Filter groups are objects that have group configuration properties and a collection of filters
 */
export default {
    id:'sorting',// id is necessary for registering a filterset filtergroup
    label : 'Sort by',
    defaultOpen: false,
    accordian:{ 
        color:{
            background: 'transparent',
            text:'#ffffff'
        }
    },
    filters:[ sortType, sortHouseId, sortTitleCode, sortPrimaryNetwork, sortCreatedDate, sortDateEdited ]
};