import sortGenre from "../filters/sort-genre";
import sortYear from "../filters/sort-year";
import sortTitle from "../filters/sort-title";
import sortTitleCode from "../filters/sort-titleCode";
import sortType from "../filters/sort-type";
import sortDateEdited from "../filters/sort-dateEdited";
import sortCreatedDate from "../filters/sort-createdDate";
import sortCountry from "../filters/sort-country";

/**
 * Filter groups are objects that have group configuration properties and a collection of filters
 */
export default {
    id:'sorting',// id is necessary for registering a filterset filtergroup
    label : 'Sort by',
    defaultOpen: false,
    accordian:{ 
        color:{
            background: 'transparent',
            text:'#ffffff'
        }
    },
    filters:[ sortTitle, sortTitleCode, sortGenre, sortType, sortCreatedDate, sortDateEdited, sortYear, sortCountry ]
};