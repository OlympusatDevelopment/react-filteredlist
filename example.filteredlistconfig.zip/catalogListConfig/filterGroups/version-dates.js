import dateCreatedRange from '../filters/dateCreatedRange';
import dateEditedRange from '../filters/dateEditedRange';

/**
 * Filter groups are objects that have group configuration properties and a collection of filters
 */
export default {
    label : 'Dates',
    defaultOpen: false,
    accordian:{
        color:{
            background: '#105caa',
            text:'#fff'
        }
    },
    filters:[
        dateCreatedRange,
        dateEditedRange
    ]
};