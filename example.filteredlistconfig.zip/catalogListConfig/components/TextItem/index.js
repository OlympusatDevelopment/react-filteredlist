import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import utils from '../../../../../appUtils';
import copy from 'copy-to-clipboard';
import config from '../../config';
import _utils from '../../_utils';


class CustomTextItem extends Component { // eslint-disable-line react/prefer-stateless-function
  constructor(props) {
    super(props);
    this.state = {
      downtime: 0
    };
    this.copyToClipboard = this.copyToClipboard.bind(this);
  }

  copyToClipboard(val, e) {
    copy(val);

    this.props.parentProps.config.notify(`Copied ${val} to the clipboard`, 'success', 'br');
  }

  onLinkClick(e) {
    const { item, selectedView } = this.props,
      date = new Date();

    // If mouse down was held, don't go to link
    if ((date - this.state.downtime) > 350) {
      return false;
    }

    // Prevent linking when the copy icon is clicked
    if (e.target.classList.contains('dl__textItem-item--copy')) {
      return false;
    }
    //Redirect to series if parent is an episode
    else if (item.entityParentType === 'olyplat-entity-episode') {

      const opts = {
        method: 'POST',
        uri: config.seriesParentApiUrl,
        body: JSON.stringify({ entityUUID: item.entityUUID }),
        headers: {
          'Content-Type': 'application/json'
        }
      };

      _utils.request(opts).then(res => {
        window.location.href = `${config.itemLinkBaseUrl}/catalog/series/${res.Items[0].parentEntity.parentEntity.parentEntity.entityUUID}/episode/${res.Items[0].parentEntity.entityUUID}#t=${item.entityUUID}`;
      });
    } else if (item.entityParentType === 'olyplat-entity-movie') {
      e.preventDefault();

      window.location.href = `${config.itemLinkBaseUrl}/catalog/movie/${item.entityParentUUID}#t=${item.entityUUID}`;
    } else {
      window.location.href = selectedView.link.row(item);

    }

  }

  // Track time on mouse down
  onMouseDown(e) {
    const date = new Date();
    this.setState({ downtime: date });

  }

  renderHTML(html) {
    return (<span dangerouslySetInnerHTML={{ __html: html }} title={html}></span>);
  }

  render() {
    const { item, selectedView } = this.props;
    const props = selectedView.props;
    const self = this; 

    return (
      <div className="dl__textItem">
        <div onMouseDown={e => this.onMouseDown(e)} onMouseUp={e => this.onLinkClick(e)}>
          {
            props.map(prop => {
              const id = item[prop.idKey],
                val = item[prop.key],
                hookedVal = prop.hasOwnProperty('before') ? prop.before(val) : val,
                parsedVal = prop.isDate ? utils.convertDateString(hookedVal) : this.renderHTML(hookedVal),
                copyIcon = prop.hasCopy ? (<span className="dl__textItem-item--copy" onClick={e => self.copyToClipboard(hookedVal, e)}> </span>) : '';

              if (prop.display) {
                return (<span key={prop.key} data-id={id} style={{ width: prop.width }} className="dl__textItem-item" >{copyIcon}{parsedVal}</span>);
              }
            })
          }
        </div>
      </div>
    );
  }
}

export default CustomTextItem;