Uses: react-fontawesome
`npm install --save react-fontawesome`