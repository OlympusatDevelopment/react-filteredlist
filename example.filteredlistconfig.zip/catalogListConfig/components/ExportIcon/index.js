import React, { Component } from 'react';
import FontAwesome from 'react-fontawesome';

class ExportIcon extends Component {
    constructor(props) {
        super(props)
    }

    iconClick(){
        Session.set('showCatalogExportsAdv', true);
        Session.set('filtersQueryObject', Session.get('currentFilterQueryObject'));
    }

    render() {

        return (
            <div title="Export" className="exportIcon" onClick={this.iconClick.bind(this)}>
                <FontAwesome name='cloud-download' />
            </div>);
    }
}

export default ExportIcon; 