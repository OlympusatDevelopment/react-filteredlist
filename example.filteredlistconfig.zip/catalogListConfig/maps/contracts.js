export default {
    "olyplat-entity-contract": 'contract'
};
