export default {
    genres: 'primaryGenre',
    languages: "language",
    dateCreated:'entityCreated'
};