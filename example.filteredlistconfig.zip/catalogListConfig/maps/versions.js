export default {
    "broadcast": 'Broadcast',
    "night-hd": 'Night HD',
    "night-sd": 'Night SD',
    "nightalt-hd": 'NightHD Alt',
    "nightalt-sd": 'NightSD Alt',
    "day-sd": 'Day SD',
    "day-hd": 'Day HD',
    "dayalt-hd": 'DayHD Alt',
    "dayalt-sd": 'DaySD Alt',
    "CensoredUnSeg-hd": 'CensoredUnSeg HD',
    "UncensUnSeg-hd": 'UncensUnSeg HD'
};
