import catalog from './catalog';

export default{
    catalog
}