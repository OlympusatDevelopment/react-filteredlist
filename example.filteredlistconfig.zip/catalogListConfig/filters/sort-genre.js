const filterKey = "sort-primaryGenre";

export default {
    id: filterKey,
    type:'sort',
    prop: filterKey,
    label: '',
    value:null//used this to set a default value. Value must be null or undefined to be excluded. Filters recognize boolean true/false
};