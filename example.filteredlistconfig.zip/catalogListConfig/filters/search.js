export default {
    id: 'search',
    type:'search',
    prop: 'search',
    label: 'Search',
    value:null,//used this to set a default value. Value must be null or undefined to be excluded. Filters recognize boolean true/false
};