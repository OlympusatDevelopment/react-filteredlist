import Promise from 'bluebird';
import _utils from '../_utils';

const filterKey = 'state';


export default {
    id: filterKey,
    type:'select',
    prop: filterKey,
    label: 'State',
    value:null,//used this to set a default value. pValue must be null or undefined to be excluded. Filters recognize boolean true/false
    multiple : true,
    options : {
        key : 'entityUUID',
        value : 'entityValue',

        // Must return a collection
        getOptions : ()=>new Promise((resolve,reject)=>{
            resolve(_utils.defaults.appendToCollection(filterKey,[
                {entityUUID:'cbd0a696-2b4f-4469-85d1-f7027345e3e0', entityValue:'meta'},
                {entityUUID:'307b5d5b-fc81-409f-972f-a8b7aa688730', entityValue:'created'},
                {entityUUID:'4eb565ce-9cfc-4f7d-84d0-e6a750bc3a8b', entityValue:'error-segments'},
                {entityUUID:'28aeb86c-b62d-43d3-871a-c6239649c62f', entityValue:'qc'},
                {entityUUID:'1e686979-6573-4dd1-ad01-024f1fd962ec', entityValue:'error-meta'},
                {entityUUID:'91538c61-29dd-4583-8377-c04559f6200e', entityValue:'segments'},
                {entityUUID:'87fcc016-b4f6-45d2-8c1d-0a1bd0a78db2', entityValue:'complete'}
            ])[filterKey]);
        })
    }
};