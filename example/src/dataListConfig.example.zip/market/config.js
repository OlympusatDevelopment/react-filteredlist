export default{
    buyerApiUrl : 'https://iq2amym85a.execute-api.us-east-1.amazonaws.com/dev/entity/olyplat-entity-catalog/get_all_for_state/_',
    sellerApiUrl : 'https://iq2amym85a.execute-api.us-east-1.amazonaws.com/dev/entity/olyplat-entity-catalog/get_all_for_state/_',
    defaultsApiUrl:'https://iq2amym85a.execute-api.us-east-1.amazonaws.com/dev/entity/olyplat-defaults/get_defaults',
    assetsApiUrl:'https://iq2amym85a.execute-api.us-east-1.amazonaws.com/dev/entity/olyplat-assets/getassets',
    tokenLocalStorageKey : 'olyauth.id_token',
    itemLinkBaseUrl : window.location.origin
};