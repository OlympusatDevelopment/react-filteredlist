
export default {
    id: 'dateEdited',
    type:'range',
    prop: 'dateEdited',
    label: 'Date Edited',
    range:{
        start:null,//used this to set a default value. Value must be null or undefined to be excluded. Filters recognize boolean true/false
        end:null,//used this to set a default value. Value must be null or undefined to be excluded. Filters recognize boolean true/false
    }

};