/**
 * Views are a collection of filter group objects
 */
import buyer from './buyer';

export default [
    buyer
];