/**
 * This is the main configuration for the list portion of the DataList component.

 */
export default {
    height:'95vh',
    paginationBottomPosition: '-9px'
}