export default {
    "olyplat-entity-movie": 'movie',
    "olyplat-entity-series": 'series',
    "olyplat-entity-episode": 'episode',
    "olyplat-entity-season": 'season',
    "olyplat-entity-version": 'version',
};
