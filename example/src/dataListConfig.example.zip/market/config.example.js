export default{
    buyerApiUrl : '',
    sellerApiUrl : '',
    defaultsApiUrl:'',
    assetsApiUrl:'',
    tokenLocalStorageKey : '',
    itemLinkBaseUrl : ''
};